package com.app.test;

import java.util.Date;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.SpringApplicationConfiguration;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.app.SpringBootApplicationExample;
import com.app.dao.NewsDao;
import com.app.model.News;
import com.app.service.NewsService;


/**
 * 
 * Test class to test dao and service layer working
 * 
 * @author ajaypu
 *
 */

@SpringApplicationConfiguration(classes = SpringBootApplicationExample.class)
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class NewsServiceImplTest
{	
	@Autowired
	NewsService newsService;
	
	NewsDao newsDao;
	
	@Autowired
	@Qualifier("newsDao")
	public void newsDao()
	{
		this.newsDao = Mockito.mock(NewsDao.class);
	}
	
	@Test
	public void whenNewsDetailIsProvided_thenUpdatedDetailIsCorrect()
	{
		System.out.println("TEST IS RUNNING.............................................................................\n");
		News exNews = newsService.findOne(1);
		System.out.println(exNews+"################\n");
		exNews.setDate(new Date());
		exNews.setDescription("HDHDHDHD");
		exNews.setHeadline("HDHDHD");
		
		Mockito.when(newsDao.save(exNews)).thenReturn(exNews);
		News acNews = newsService.findOne(exNews.getIdnews());
		try
		{
			Assert.assertEquals(exNews, acNews);
			System.out.println("Successful "+exNews+" == "+acNews);
		}
		catch(AssertionError  e)
		{
			System.out.println("Failed "+exNews+" == "+acNews);
		}
		System.out.println(" *********************************************************************** Assert finish");	
	}

}
