package com.app.test;


import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.app.SpringBootApplicationExample;

import com.app.dao.UserDao;
import com.app.model.User;

import com.app.service.UserService;
import com.app.util.AESencrp.AESencrp;

/**
 * 
 * Test class to test dao and service layer working
 * 
 * @author ajaypu
 *
 */

@SpringApplicationConfiguration(classes = SpringBootApplicationExample.class)
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class UserServiceImplTest
{	
	@Autowired
	UserService userService;
	
	UserDao userDao;
	
	@Autowired
	@Qualifier("userDao")
	public void userDao()
	{
		this.userDao=  Mockito.mock(UserDao.class);
	}
	
	@Test
	public void whenUserDetailIsProvided_thenRetrievedUserDetailIsCorrect() throws Exception
	{
		User exUser = new User("Ajay P","ajaypu@cybage.com", "ajay", "user");
		Mockito.when(userDao.findByEmailIdAndPassword("ajaypu@cybage.com", "ajay")).thenReturn(exUser);
		User acUser = userService.findByEmailIdAndPassword("ajaypu@cybage.com", AESencrp.encrypt("ajay"));
		try
		{
			Assert.assertEquals(exUser, acUser);
			System.out.println("Successful "+exUser+" == "+acUser);
		}
		catch(AssertionError  e)
		{
			System.out.println("Failed "+exUser+" == "+acUser);
		}
		System.out.println(" *********************************************************************** Assert finish");
	}
}
