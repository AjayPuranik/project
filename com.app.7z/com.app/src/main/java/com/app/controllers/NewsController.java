package com.app.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.app.model.News;
import com.app.model.User;
import com.app.service.NewsService;
import com.app.util.customerror.CustomErrorType;

/**
 * 
 * Main class which controlling all navigation of pages and will produce and consume json data as required
 * 
 * @author ajaypu
 *
 */

@ComponentScan
@RestController
@RequestMapping("/todays")
public class NewsController
{
	@Autowired
	 NewsService newsService; //Service which will do all data retrieval/manipulation work
	
	 // ------------------- Retrieve All News ---------------------------------------------
	
	@RequestMapping(value="/allnews",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<News>> getAllNews()
	{
		List<News> news = newsService.findAll();
		if(news  == null)
		{
			return new ResponseEntity<List<News>>(HttpStatus.NO_CONTENT);
		}
 		return  new ResponseEntity<List<News>>(news,HttpStatus.OK);
	}

	
	 // ------------------- Retrieve Single News ------------------------------------------
	
	@RequestMapping(value="/news/{id}",method=RequestMethod.GET)
	public ResponseEntity<?> getNewsById(@PathVariable(value="id") int id)
	{
		News news = newsService.findOne(id);
		System.out.println("********************************"+news);
		if(news  == null)
		{
			return new ResponseEntity<>(new CustomErrorType("User with id "+id+" not found."), HttpStatus.NOT_FOUND);
		}
 		return  new ResponseEntity<News>(news, HttpStatus.OK);
	}
	
	 // -------------------Create a News-------------------------------------------
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public  ResponseEntity<?> addNews(@RequestBody News news,  UriComponentsBuilder ucBuilder)
	{
		
		if (newsService.findByHeadline(news.getHeadline()) == null)
		{
            return new ResponseEntity<>(new CustomErrorType("Unable to create. A News with headline " + news.getHeadline() + " already exist."),HttpStatus.CONFLICT);
        }
		//assigning user to  the news with the date and time
		User u = new User();
		u.setIduser(10);
		news.setDate(new Date());
		news.setUser(u);
		newsService.saveNews(news);
		//System.out.println(news);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/todays/news/{id}").buildAndExpand(news.getIdnews()).toUri());
        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
	}
	
	// ------------------- Update a News ------------------------------------------------
	
	@RequestMapping(value="/news/{id}",method=RequestMethod.PUT)
	public  ResponseEntity<?> updateNews(@PathVariable("id") int id,  @RequestBody News news)
	{
		News currentNews = newsService.findOne(id);
		
		if (currentNews == null)
		{
            return new ResponseEntity<>(new CustomErrorType("Unable to update. A News with id " + news.getIdnews() + " not found."),HttpStatus.CONFLICT);
        }

		//assigning user to  the news with the date and time
		currentNews.setDate(new Date());
		currentNews.setDescription(news.getDescription());
		currentNews.setHeadline(news.getHeadline());
		currentNews.setUser(news.getUser());
		newsService.saveNews(currentNews);
        
        return new ResponseEntity<News>(currentNews, HttpStatus.OK);
	}
	
	 // ------------------- Delete a News-----------------------------------------
	  
	@RequestMapping(value = "/news/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteNews(@PathVariable("id") int id)   
	{
		  News news = newsService.findOne(id);    
	        if (news == null) 
	        {   
	        	return new ResponseEntity<>(new CustomErrorType("Unable to delete. News with id " + id + " not found."),HttpStatus.NOT_FOUND);
	        }
	        
	        newsService.delete(id);
	        return new ResponseEntity<News>(HttpStatus.NO_CONTENT);
	    }
	
	
}