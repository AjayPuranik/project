package com.app.controllers;

import java.text.ParseException;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.exception.CustomException;
import com.app.model.News;
import com.app.model.User;
import com.app.service.NewsService;
import com.app.service.UserService;

/**
 * 
 * Main controller which will navigate all the pages to the particular page
 * 
 * @author ajaypu
 *
 */

@ComponentScan
@Controller
public class MainController
{
	//Dependency Injections
	@Autowired
	 NewsService newsService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	HttpSession httpSession;

/*	public void setHttpSession(HttpSession session)
	{
		this.session =session;
	}
	*/
	
	//initial mapping for home/index page
	
	@RequestMapping("/")
	public String showhomePage(HttpServletRequest req)
	{
		//adding list the request attribute
		req.setAttribute("news_list", newsService.findAll());
		return "index";	
	}
	
	/*
	//for checking that exception handling is working or not
	 
	@RequestMapping("/ex")
	public String showExceptionPage(HttpServletRequest req)
	{
			req.setAttribute("news_list", newsService.findAll());
			throw new BaseException("asdkasdkakdskd");
	}
	*/
	
	//simply forward to the login page
	
	@RequestMapping("/login")
	public String showloginPage()
	{
		return "login";	
	}
	
	//simply forward to the register page
	
	@RequestMapping("/register")
	public String showRegisterPage()
	{
		return "newUser";	
	}
	
	//getting user details and adding to db
	
	@RequestMapping("/saveUser")
	public String processRegisterPage(@ModelAttribute User user,BindingResult rs, HttpServletRequest req) throws Exception
	{
			System.out.println(user);
			if(userService.checkEmailId(user))
			{
				req.setAttribute("emailid", "Registed Successfully with "+user.getEmailId()+".");
				return "newUser";	
			}
			else
			{
				req.setAttribute("emailid", "Please try for another email id.");
				return "newUser";
			}
	}
	
	//if session object is active then simply forward to page
	
	@RequestMapping(value="/logged",method=RequestMethod.GET)
	public String showloginPage(HttpServletRequest req,ModelMap map)
	{
		//Getting the session object if it is present
		HttpSession s = req.getSession(false);
		//checking that the session object is not null 
		if(s != null)
		{
			User u = (User)s.getAttribute("loggedUser");
			req.setAttribute("news_list", newsService.findAllByUser(u));
			return "user";
		}
		
		return "login";
	}
	
	public String  processToLoadDetails(HttpServletRequest req,ModelMap map)
	{
		
		return "";
	}
	
	
	//authenticating user with the credential
	
	@RequestMapping(value="/logged",method=RequestMethod.POST)
	public String processloginPage(@ModelAttribute User user,BindingResult rs ,HttpServletRequest req,ModelMap map) throws Exception
	{
		HttpSession s = req.getSession(false);
		if(s != null)
		{
			if(userService.authenticateUser(user.getEmailId(), user.getPassword()))
			{
				User u =  userService.findByEmailId(user.getEmailId());
				req.setAttribute("news_list", newsService.findAllByUser(u));
				//storing the object(user)
				s.setAttribute("loggedUser",u);
				return "user";
			}
			else
			{
				throw new CustomException();
			}
		}
		map.addAttribute("status", "Invalid Username Or Password");
		return "login";
	}
	
	//logging out to the particular user 
	
	@RequestMapping("/logout")
	public String processLogoutPage(ModelMap map, HttpServletRequest req)
	{
		HttpSession s = req.getSession(false);
		if(s != null)
		{
			//Invalidating session
			httpSession.invalidate();
			s.invalidate();
			map.addAttribute("status", "Successfully Logged Out ... !");
		}
		return "login";
	}
	
	//adding news with the date and user details
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String processSavePage(@ModelAttribute News news,BindingResult rs ,HttpServletRequest req)
	{
		HttpSession s = req.getSession(false);
		if(s != null)
		{
			User u = (User)s.getAttribute("loggedUser");
			//assigning user to the news i.e. who is adding the news
			news.setUser(u);
			//assigning particular date and time to the news
			news.setDate(new Date());
				/////////////////////////////////
				//news = null;
				//news.getDate();
				/////////////////////////////////
			//adding the news
			newsService.saveNews(news);
			req.setAttribute("news_list", newsService.findAllByUser(u));
			return "user";
		}
		return "login";
	}
	
	//simply forward to the add page
	
	@RequestMapping(value="/add",method=RequestMethod.GET)
	public String showAddPage(HttpServletRequest req)
	{
		HttpSession s = req.getSession(false);
		if(s != null)
		{
			return "add";	
		}
		return "login";
	}
	
	//searching the news by the date
	
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public String processSearchPage(@RequestParam("s") String sdate ,HttpServletRequest req, ModelMap map) throws ParseException
	{
		HttpSession s = req.getSession(false);
		if(s != null)
		{
				//if object is not empty or not null
			Date date = newsService.checkDateFormat(sdate);
			if(date != null)
			{
				//adding the date for which the result searched
				map.addAttribute("Result", "Search Result By "+date);
				//adding search result to request attribute
				req.setAttribute("news_list", newsService.findByDate(date));
				return "index";
			}
		}
		req.setAttribute("news_list", newsService.findAll());
		return "index";
	}
	
	//forwarding to the update with particular object of news 
	
	@RequestMapping(value="/update",method=RequestMethod.GET)
	public String processUpdatePage(@RequestParam("id") Integer id ,HttpServletRequest req, ModelMap map)
	{
		HttpSession s = req.getSession(false);
		if(s != null)
		{
			if(id != null)
			{
				//finding object by the id
				map.addAttribute("news", newsService.findOne(id));
			}
			/*User u = (User)s.getAttribute("loggedUser");
			req.setAttribute("news_list", newsService.findAllByUser(u));*/
			return "add";	
		}
		return "login";
	}
	
	//deleting the particular news
	
	@RequestMapping(value="/delete")
	public String processDeletePage(@RequestParam("id") Integer id ,HttpServletRequest req)
	{
		HttpSession s = req.getSession(false);
		if(s != null)
		{
			//deleting the object by the id
			newsService.delete(id);
			User u = (User)s.getAttribute("loggedUser");
			req.setAttribute("news_list", newsService.findAllByUser(u));
			return "user";	
		}
		return "login";
	}
}
