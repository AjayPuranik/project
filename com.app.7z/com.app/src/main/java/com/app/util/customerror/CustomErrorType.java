package com.app.util.customerror;

/**
 * 
 * Used in rest controller to show the error message
 * 
 * @author ajaypu
 *
 */

public class CustomErrorType
{
	private String errorMessage;
	 
    public CustomErrorType(String errorMessage)
    {
        this.errorMessage = errorMessage;
    }
 
    public String getErrorMessage() 
    {
        return errorMessage;
    }
}
