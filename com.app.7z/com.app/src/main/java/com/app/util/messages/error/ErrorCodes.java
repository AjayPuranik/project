package com.app.util.messages.error;

/**
 * 
 * Error codes for custom exception 
 * 
 * @author ajaypu
 *
 */

public interface ErrorCodes
{
	 String CUSTOM_EXCEPTION_1="this is custom exception that....";
}
