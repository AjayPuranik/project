package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.UserDao;
import com.app.model.User;
import com.app.util.AESencrp.AESencrp;

/**
 * 
 * Implementation of all methods of service interface and business logic for scenario
 * 
 * @author ajaypu
 *
 */

@ComponentScan
@Service
@Transactional
public class UserServiceImpl implements UserService
{
	@Autowired
	UserDao userDao;
	
	@Override
	public void saveUser(User user)
	{
		userDao.save(user);
	}

	@Override
	public User findOne(Integer id)
	{
		return userDao.findOne(id);
	}

	@Override
	public void delete(Integer id)
	{
		userDao.delete(id);
	}

	@Override
	public User findByEmailIdAndPassword(String email_Id, String password)
	{
		return userDao.findByEmailIdAndPassword(email_Id, password);
	}
	
	@Override
	public User findByEmailId(String email_Id)
	{
		return userDao.findByEmailId(email_Id);
	}
	
	@Override
	public boolean checkEmailId(User user) throws Exception
	{
		if(this.findByEmailId(user.getEmailId()) == null)
		{
			user.setPassword(AESencrp.encrypt(user.getPassword()));
			user.setRole("user");
			this.saveUser(user);
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@Override
	public boolean authenticateUser(String email_Id, String password) throws Exception
	{
		//Getting object by calling method with the credential
		User loginUser = this.findByEmailIdAndPassword(email_Id, AESencrp.encrypt(password));
		//if object is not null i.e. credentials are correct
		if( loginUser != null)
		{
			return true;
		}
		return false;
	}
}
