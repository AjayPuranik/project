package com.app.service;

/**
 * 
 * Interface for loosely coupled architecture
 * 
 * @author ajaypu
 *
 */

import com.app.model.User;

public interface UserService
{
	public void saveUser(User user);
	
    public User findOne(Integer id);

    public void delete(Integer id);
    
    public User findByEmailIdAndPassword(String email_Id, String password); 
    
    public User findByEmailId(String email_Id);
    
    public boolean checkEmailId(User user) throws Exception;
    
    public boolean authenticateUser(String email_Id, String password) throws Exception;
}
