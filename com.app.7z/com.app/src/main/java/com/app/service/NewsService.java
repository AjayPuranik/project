package com.app.service;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.app.model.News;
import com.app.model.User;

/**
 * 
 * Interface for loosely coupled architecture
 * 
 * @author ajaypu
 *
 */

public interface NewsService
{
		public List<News> findAll();
	
		public void saveNews(News news);

	    public News findOne(Integer id);

	    public void delete(Integer id);

	    public List<News> findByHeadline(String name);

	    public List<News> findByDate(Date date);
	    
	    public Date checkDateFormat(String sdate)throws ParseException;
	    
	    public List<News> findAllByUser(User user);
}
