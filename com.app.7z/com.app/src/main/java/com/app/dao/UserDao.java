package com.app.dao;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.repository.CrudRepository;

import com.app.model.User;

/**
 * 
 *  Interface which provide all CRUD operation 
 * 
 * @author ajaypu
 *
 */

@ComponentScan
public interface UserDao extends CrudRepository<User, Integer>
{
	//getting user by the credentials
	public User findByEmailIdAndPassword(String emailId, String password); 
	
	 public User findByEmailId(String emailId);
}

