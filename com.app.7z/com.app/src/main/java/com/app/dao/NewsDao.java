package com.app.dao;

import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.app.model.News;
import com.app.model.User;


/**
 * 
 * Interface which provide all CRUD operation 
 * 
 * @author ajaypu
 *
 */

@ComponentScan
public interface NewsDao extends CrudRepository<News, Integer>
{
	//getting all records by date
	@Query("select n from News n " +"where DATE(n.date) = ?1")
	public List<News> findByDate(Date date);
	
	@Query("select n from News n " +"where n.headline = ?1")
	public List<News> findByHeadline(String name);
	
	@Query("select n from News n " +"where n.user = ?1")
	 public List<News> findAllByUser(User user);
}
