package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *  
 * Application class to load spring boot application
 *
 * @author ajaypu
 *
 */

@SpringBootApplication
public class SpringBootApplicationExample
{
	/* To run application  */
	public static void main(String[] args)
	{
		SpringApplication.run(SpringBootApplicationExample.class, args);
	}
}
 