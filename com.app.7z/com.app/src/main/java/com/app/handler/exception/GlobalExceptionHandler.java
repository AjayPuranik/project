package com.app.handler.exception;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.app.exception.BaseException;

/**
 * 
 * Global exception handler for all exceptions
 * 
 * @author ajaypu
 *
 */


/*Handle all runtime user defined exception which are thrown by developer */
@Controller
@ControllerAdvice
public class GlobalExceptionHandler
{
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value=BaseException.class)
	public ModelAndView handleBaseException(BaseException e)
	{
		System.out.println("........Base Excep.....");
		ModelAndView mod = new ModelAndView();
		mod.addObject("status", e);
		mod.setViewName("excep");
		return mod;
	}
	
/*Handle all exception other than user defined */
	@ExceptionHandler(value=Exception.class)
	public ModelAndView handleException(Exception e)
	{
		System.out.println("...Exception.....");
		ModelAndView mod = new ModelAndView();
		mod.addObject("status", e);
		mod.setViewName("excep");
		return mod;
	}

	/*	
 	public String handleBaseException(BaseException e, HttpServletRequest req)
	{
		req.setAttribute("status", e.getCause());
		return "excep";
	}
	
	@ExceptionHandler(value=Exception.class)
	public String handleException(Exception e,HttpServletRequest req)
	{
		req.setAttribute("status", e.getCause());
		return "excep";
	}
	*/
}
