package com.app.model;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;

import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * User as domain class
 */
@Entity
@Table(name = "user", catalog = "news_media", uniqueConstraints = @UniqueConstraint(columnNames = "email_Id"))
public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5552377696509607402L;
	private int iduser;
	private String name;
	private String email_Id;
	private String password;
	private String role;

	public User() {
	}

	public User(String name, String emailId, String password, String role) {
		this.name = name;
		this.email_Id = emailId;
		this.password = password;
		this.role = role;
	}

	public User(String name, String emailId, String password, String role, Set<News> newses) {
		this.name = name;
		this.email_Id = emailId;
		this.password = password;
		this.role = role;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "iduser", unique = true, nullable = false)
	public int getIduser() {
		return this.iduser;
	}

	public void setIduser(int iduser) {
		this.iduser = iduser;
	}

	@Column(name = "name", nullable = false, length = 45)
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "email_Id", unique = true, nullable = false, length = 45)
	public String getEmailId() {
		return this.email_Id;
	}

	public void setEmailId(String emailId) {
		this.email_Id = emailId;
	}

	@Column(name = "password", nullable = false, length = 45)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "role", nullable = false, length = 45)
	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		 if (obj == null) {
	         return false;
	     }
	     if (this.getClass() != obj.getClass()) {
	    	 return false;
	     }
	     final User other = (User) obj;

	     if (this.getEmailId().equals(other.getEmailId())){
	          return true;
	     }
	      return false;
	}
	
	@Override
	public int hashCode()
	{
		return super.hashCode();
	}
	
	@Override
	public String toString()
	{
		return "User [iduser=" + iduser + ", name=" + name + ", emailId=" + email_Id + ", password=" + password
				+ ", role=" + role + "]";
	}
	
}
