package com.app.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * News as domain class
 */
@Entity
@Table(name = "news", catalog = "news_media")
public class News implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1263599186564829307L;
	private int idnews;
	private User user;
	private Date date;
	private String headline;
	private String description;

	public News() {
	}

	public News(User user, Date date, String headline, String description) {
		this.user = user;
		this.date = date;
		this.headline = headline;
		this.description = description;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "idnews", unique = true, nullable = false)
	public int getIdnews() {
		return this.idnews;
	}

	public void setIdnews(int idnews) {
		this.idnews = idnews;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "user")
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date", length = 19)
	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Column(name = "headline", length = 75)
	public String getHeadline() {
		return this.headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	@Column(name = "description", length = 200)
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		 if (obj == null) {
	         return false;
	     }
	     if (getClass() != obj.getClass()) {
	    	 return false;
	     }
	     final News other = (News) obj;

	     if ((this.getIdnews() == other.getIdnews())){
	          return true;
	     }
	      return false;
	}
	
	@Override
	public String toString()
	{
		return "News [idnews=" + idnews + ", user=" + user + ", date=" + date + ", headline=" + headline
				+ ", description=" + description + "]";
	}
	
}
