package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Attachment;
import com.app.pojos.Requirement;
import com.app.pojos.RequirementHistory;

@Repository
public class RequirementDetailsDaoImpl implements RequirementDetailsDao
{
	@Autowired
	private SessionFactory session;

	public void insertRequirment(Requirement rd)
	{
		session.getCurrentSession().persist(rd);
	}

	public void updateRequirement(Requirement rd)
	{
		session.getCurrentSession().update(rd);
	}

	public Requirement getRequirementById(Integer id)
	{
		Requirement req = (Requirement)session.getCurrentSession().get(Requirement.class, id);
		return req;
	}

	public void insertRequirmentHistory(RequirementHistory rdh)
	{
		session.getCurrentSession().persist(rdh);
	}

	public void insertAttachment(Attachment attachment)
	{
		session.getCurrentSession().persist(attachment);
	}

	public Attachment getAttachmentById(Integer id)
	{
		return (Attachment)session.getCurrentSession().get(Attachment.class, id);
	}
}
