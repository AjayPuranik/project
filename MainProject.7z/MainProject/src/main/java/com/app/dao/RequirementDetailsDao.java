package com.app.dao;

import com.app.pojos.Attachment;
import com.app.pojos.Requirement;
import com.app.pojos.RequirementHistory;

public interface RequirementDetailsDao
{
	void insertRequirment(Requirement rd);
	
	void updateRequirement(Requirement rd);
	
	Requirement getRequirementById(Integer id);
	
	void insertRequirmentHistory(RequirementHistory rdh);
	
	void insertAttachment(Attachment attachment);
	
	Attachment getAttachmentById(Integer id);
}
