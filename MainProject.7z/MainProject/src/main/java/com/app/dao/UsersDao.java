package com.app.dao;

import com.app.pojos.User;

public interface UsersDao
{
	User getUserById(Integer id);
}
