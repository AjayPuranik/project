package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.User;

@Repository
public class UserDaoImpl implements UsersDao
{
	@Autowired
	private SessionFactory session;
	
	public User getUserById(Integer id)
	{
		User user = (User)session.getCurrentSession().get(User.class, id);
		return user;
	}

}
