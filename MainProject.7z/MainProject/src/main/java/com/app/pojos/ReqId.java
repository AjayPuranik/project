package com.app.pojos;

public class ReqId
{
	private Integer id;
	
	public ReqId()
	{
	}
	
	public Integer getId()
	{
		return id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	@Override
	public String toString()
	{
		return "ReqId [id=" + id + "]";
	}
	
}
