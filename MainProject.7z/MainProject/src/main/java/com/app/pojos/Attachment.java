package com.app.pojos;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the attachments database table.
 * 
 */
@Entity
@Table(name="attachments")
@NamedQuery(name="Attachment.findAll", query="SELECT a FROM Attachment a")
public class Attachment implements Serializable {
	private static final long serialVersionUID = 1L;
	private int attachmentId;
	private Timestamp addingTime;
	private byte[] attachment;
	private Requirement requirement;
	private User user;

	public Attachment() {
	}


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getAttachmentId() {
		return this.attachmentId;
	}

	public void setAttachmentId(int attachmentId) {
		this.attachmentId = attachmentId;
	}


	public Timestamp getAddingTime() {
		return this.addingTime;
	}

	public void setAddingTime(Timestamp addingTime) {
		this.addingTime = addingTime;
	}


	@Lob
	public byte[] getAttachment() {
		return this.attachment;
	}

	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}


	//bi-directional many-to-one association to Requirement
	@ManyToOne
	@JoinColumn(name="requirementId")
	public Requirement getRequirement() {
		return this.requirement;
	}

	public void setRequirement(Requirement requirement) {
		this.requirement = requirement;
	}


	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="userid")
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}