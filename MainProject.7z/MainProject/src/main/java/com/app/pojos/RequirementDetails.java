package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="req_mg")
public class RequirementDetails
{
	private Integer reqId;
	@NotEmpty(message="Enter Desc")
	private String descp;
	@NotEmpty(message="Enter Title")
	private String title;
	
	@Id
	@GeneratedValue
	@Column(length=20)
	public Integer getReqId()
	{
		return reqId;
	}
	
	@Column(length=20)
	public void setReqId(Integer reqId)
	{
		this.reqId = reqId;
	}
	@Column(length=20)
	public String getDescp()
	{
		return descp;
	}
	public void setDescp(String descp)
	{
		this.descp = descp;
	}
	@Column(length=20)
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}
	
	
}
