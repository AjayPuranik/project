package com.app.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.RequirementDetailsDao;
import com.app.pojos.Attachment;
import com.app.pojos.Requirement;
import com.app.pojos.RequirementHistory;

@Service
@Transactional
public class RequirementServiceImpl implements RequirementService
{
	@Autowired
	private RequirementDetailsDao dao;

	public void insertRequirment(Requirement rd)
	{
		dao.insertRequirment(rd);
	}

	public void updateRequirement(Requirement rd)
	{
		dao.updateRequirement(rd);
	}

	public Requirement getRequirementById(Integer id)
	{
		return dao.getRequirementById(id);
	}

	public void insertRequirmentHistory(RequirementHistory rdh)
	{
		dao.insertRequirmentHistory(rdh);
	}

	public void insertAttachment(Attachment attachment)
	{
		dao.insertAttachment(attachment);
	}

	public Attachment getAttachmentById(Integer id)
	{
		return dao.getAttachmentById(id);
	}
}
