package com.app.services;

import com.app.pojos.User;

public interface UserService
{
	User getUserById(Integer id);
}
