package com.app.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.UsersDao;
import com.app.pojos.User;

@Service
@Transactional
public class UserServiceImpl implements UserService
{
	@Autowired
	private UsersDao dao;
	public User getUserById(Integer id)
	{
		return dao.getUserById(id);
	}

}
