package com.app.controller;

import java.util.Date;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.app.pojos.Attachment;
import com.app.pojos.ReqId;
import com.app.pojos.Requirement;
import com.app.pojos.RequirementHistory;
import com.app.services.RequirementService;
import com.app.services.UserService;

@Controller
@RequestMapping("/req")
public class RequirementController
{
	@Autowired
	RequirementService service;
	
	@Autowired
	UserService uService;
	
	@RequestMapping(value="/form")
	public String showRequirementForm(HttpSession hs,Requirement rd, ModelMap map)
	{
		map.addAttribute("status", "Thank You...!");
		return "req_form";
	}
	
	@RequestMapping(value="/submit",method=RequestMethod.POST)
	public String processRequirementForm(Requirement rd, ModelMap map,HttpSession hs)
	{
		rd.setDeleted("N");
		rd.setUser1(uService.getUserById(1));
		rd.setUser2(uService.getUserById(1));
		rd.setUser3(uService.getUserById(1));
		rd.setCreated(new Timestamp(new Date().getTime()));
		rd.setModifiedOn(new Timestamp(new Date().getTime()));
		
		System.out.println(rd);
		service.insertRequirment(rd);
		map.addAttribute("status", "Thank You...!");
		return "success";
	}
	
	@RequestMapping(value="/fromId")
	public String showUpdateRequirementForm(HttpSession hs,ReqId rid, ModelMap map,Requirement rd)
	{
		map.addAttribute("status", "Thank You...!");
		return "update_id_form";
	}
	
	@RequestMapping(value="/getId",method=RequestMethod.POST)
	public ModelAndView processUpdateRequirementForm(ReqId rid ,HttpSession hs,Requirement rd)
	{	
		System.out.println(rid);
		Requirement r = service.getRequirementById(rid.getId());
		System.out.println(r);
		return new ModelAndView("update_form", "req", r);
	}
	
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String processUpdateRequirementForm(Requirement rd, ModelMap map,HttpSession hs)
	{
		System.out.println(rd);
		Requirement r = service.getRequirementById(rd.getRequirementId());
		System.out.println(r);
		RequirementHistory reqh= new RequirementHistory(r);
		System.out.println(reqh);
		System.out.println("Pre Requirement ::::::::::::: "+r);
		//service.insertRequirmentHistory(reqh);
		System.out.println("Pre Requirement ::::::::"+rd);
		//service.updateRequirement(rd);
		map.addAttribute("status", new String("Thank You...!"));
		return "success";
	}
	
	@RequestMapping(value="/upload")
	public String showUploadForm(HttpSession hs,Attachment doc)
	{
		return "file_upload_download";
	}
	
	@RequestMapping(value="/download")
	public String showDownloadForm(HttpSession hs,Attachment doc)
	{
		return "file_download";
	}
	
	@RequestMapping(value="/fileUpload",method=RequestMethod.POST)
	public String fileUpload(@ModelAttribute Attachment doc,@RequestParam("file") MultipartFile file) throws IOException
	{
		System.out.println("Content type :: "+file.getContentType());
		byte[] content = file.getBytes();
		doc.setAttachment(content);
		doc.setRequirement(service.getRequirementById(4));
		doc.setAddingTime(new Timestamp(new Date().getTime()));
		doc.setUser(uService.getUserById(1));
		service.insertAttachment(doc);
		return "success";
	}
	

	@RequestMapping(value="/fileDownload", method=RequestMethod.GET)
	public String fileDownload(@RequestParam("id") Integer id, HttpServletResponse response) 
	{
			System.out.println("ididididid"+id);
			Attachment attachment= service.getAttachmentById(id);
		try {
			response.setHeader("Content-Disposition", "inline;filename=\"" +attachment.getAttachmentId()+ "\"");
			OutputStream out = response.getOutputStream();
			response.setContentType("application/pdf");
			InputStream stream = new ByteArrayInputStream(attachment.getAttachment());
			IOUtils.copy(stream, out);
			out.flush();
			out.close();
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "success";
	}
}
